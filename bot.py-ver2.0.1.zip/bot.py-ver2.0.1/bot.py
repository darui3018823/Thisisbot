import discord
from discord.ext import commands
from discord import app_commands
import whois
import ntplib
from datetime import datetime, timedelta
import re
import os

intents = discord.Intents.default()
intents.message_content = True
intents.dm_messages = True

bot = commands.Bot(command_prefix='daruks!', intents=intents)

ADMIN_USER_ID = 973782871963762698
ADMIN_ID_FILE = 'admin.txt'
NTP_SERVER = 'ntp.nict.jp'

def save_admin_id(user_id):
    with open(ADMIN_ID_FILE, 'a') as f:
        f.write(f'{user_id}\n')

def load_admin_ids():
    if not os.path.exists(ADMIN_ID_FILE):
        return set()
    with open(ADMIN_ID_FILE, 'r') as f:
        return set(line.strip() for line in f)

def delete_admin_id(user_id):
    admin_ids = load_admin_ids()
    admin_ids.discard(str(user_id))
    with open(ADMIN_ID_FILE, 'w') as f:
        for admin_id in admin_ids:
            f.write(f'{admin_id}\n')

def is_admin(user_id):
    admin_ids = load_admin_ids()
    return str(user_id) in admin_ids

def admin_only():
    def predicate(ctx):
        return ctx.author.id == ADMIN_USER_ID
    return commands.check(predicate)

def get_japan_time():
    try:
        client = ntplib.NTPClient()
        response = client.request(NTP_SERVER, version=3)
        return datetime.fromtimestamp(response.tx_time)
    except Exception as e:
        print(f"Error fetching NTP time: {e}")
        return datetime.utcnow() + timedelta(hours=9)

def get_whois_info(ip_address):
    try:
        # IPv4 アドレスの正規表現
        ipv4_pattern = r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"
        
        # IPv4 アドレスの検証
        if not re.match(ipv4_pattern, ip_address):
            return "送信されたアドレスはIPv4の形式ではないようです。お手数ですが再度お試しください。入力されたアドレス: {}".format(ip_address)
        
        info = whois.whois(ip_address)
        return str(info)
    except whois.parser.PywhoisError:
        return "検索に失敗しました。再度お試しください。"
    except Exception as e:
        return f"不明なエラーが発生しました。: {e}"

#calc command
def calculate(expression):
    try:
        expression = expression.replace('+', '+').replace('ー', '-').replace('×', '*').replace('÷', '/')
        result = eval(expression)
        return result
    except Exception as e:
        return f"エラーが発生しました: {str(e)}"

@bot.command()
async def calc(ctx, *, expression: str):
    result = calculate(expression)
    await ctx.send(f'計算結果: {result}')


#Set PlayNow game
@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')
    activity = discord.Game(name="平和にいこうよ〜🥰")
    await bot.change_presence(activity=discord.CustomActivity("平和に逝こうよ～🥰 "))

@bot.command()
@admin_only()
async def load(ctx, extension):
    await bot.load_extension(f'cogs.{extension}')
    await ctx.send(f'Loaded {extension}')

@bot.command()
@admin_only()
async def unload(ctx, extension):
    await bot.unload_extension(f'cogs.{extension}')
    await ctx.send(f'Unloaded {extension}')

@bot.command()
async def myid(ctx):
    await ctx.send(f'Your ID is {ctx.author.id}')

@bot.command()
async def jst(ctx):
    now = get_japan_time()
    await ctx.send(f'JST: {now}')

@bot.command()
async def ping(ctx):
    await ctx.send(f'Pong! {round(bot.latency * 1000)}ms')

@bot.command()
async def whois(ctx, ip_address: str, ipv4: bool = False):
    info = get_whois_info(ip_address, ipv4)
    await ctx.send(f'Whois info: {info}')

@bot.command()
@commands.has_permissions(administrator=True)
async def add_admin(ctx, user_id: int):
    if not is_admin(user_id):
        save_admin_id(user_id)
        await ctx.send(f'Added {user_id} as admin')
    else:
        await ctx.send(f'{user_id} is already an admin')

@bot.command()
@commands.has_permissions(administrator=True)
async def remove_admin(ctx, user_id: int):
    if is_admin(user_id):
        delete_admin_id(user_id)
        await ctx.send(f'Removed {user_id} from admins')
    else:
        await ctx.send(f'{user_id} is not an admin')

@bot.event
async def on_message(message):
    if message.content.startswith('daruksh!'):
        cmd = message.content.split('!')[1]
        help_msgs = {
            'delete': 'bot massage delete\n`daruks!delete `\n※Please send it by reply',
            'myid': 'Display your user ID\n`daruks!myid `',
            'help': 'This command\n`daruks!help `',
            'jst': 'Display Japanese time\n`daruks!jst `',
            'ping': 'Display latency\n`daruks!ping `',
            'whois': 'Display whois\n`daruks!whois [IP address] `'
        }
        if cmd in help_msgs:
            await message.reply(help_msgs[cmd])
        else:
            await message.reply("Unknown command.")
    await bot.process_commands(message)

@bot.event
async def on_message(message):
    if message.author.bot:
        return  # ボットのメッセージは無視

    if isinstance(message.channel, discord.DMChannel):
        if message.content == "daruks!contact":
            await message.author.send(
                "ご連絡ありがとうございます。\nリプライをせずにこのメッセージのあとに、main!を付けて送信くださいませ。\n以下にテンプレートを掲載します。ご利用ください。\nキャンセルする際はcancel!とご入力ください。\nメールでのご連絡をご希望の場合はmail!とご入力ください。\n※お問い合わせ内容は1,2行で簡潔にご記入ください\n※ユーザー名は返信を希望される場合は記入ください。\n\nmain!\nお問い合わせ内容:\nユーザー名:\n利用端末:\n本文:"
            )
        elif message.content == "cancel!":
            await message.author.send("チケットを終了しました。\n再度ご利用になる場合は`daruks!contact`とご入力ください。")
        elif message.content == "mail!":
            await message.author.send(
                "メールでのご連絡を承ります。\n以下の情報を送信ください。\nsent!を先頭につけることで送信できます\nメールアドレス:\nご連絡を希望のメールアドレス:\nお問い合わせ内容:"
            )
        elif message.content.startswith("main!"):
            owner = await bot.fetch_user(973782871963762698)
            await owner.send(
                f"{message.content}\n\n送信者詳細\nユーザー名: {message.author.name}\nユーザーID: {message.author.id}\n送信日時: {message.created_at}"
            )
            await message.author.send(
                "ご連絡ありがとうございます。\n送信が完了しました。daruからのご連絡が数日以内にありますので、今しばらくお待ちください。"
            )
        elif message.content.startswith("sent!"):
            owner = await bot.fetch_user(973782871963762698)
            await owner.send(
                f"{message.content}\n\n送信者詳細\nユーザー名: {message.author.name}\nユーザーID: {message.author.id}\n送信日時: {message.created_at}"
            )
            await message.author.send(
                "ありがとうございます。\n確認次第、お問い合わせ内容の再確認メールをこちらから送信いたします。\n@icloud.comからのメールがブロックされている場合はメールが届かない可能性があります。"
            )
    else:
        if message.content == "daruks!contact":
            await message.channel.send("このコマンドはDMでのみ使用できます。")


# メッセージ受信イベント
@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    bad_words = ["死ね", "しね", "シネ", "カス", "かす"]
    for word in bad_words:
        if word in message.content:
            await message.reply("そんなこと言うのは良くないよお前が死ね")
            return

    kazume_words = ["かずめ", "kazume", "ぴぃまん", "ぴいまん"]
    for word in kazume_words:
        if word in message.content:
            await message.reply("捕まろうよ〜🥰")
            return

    osu_words = ["osu!", "osu", "kasu!", "gomi!", "otu!"]
    for word in osu_words:
        if word in message.content:
            await message.reply("お前もwelcome to osu!")
            return

    paypal_words = ["ぺいぱる", "ペイパル", "PayPal"]
    for word in paypal_words:
        if word in message.content:
            await message.reply("割ってなんぼやで😎")
            return

    if "えっち" in message.content:
        await message.reply("えっちなのはダメ!死刑!!")
        return

    await bot.process_commands(message)

