"""
ja:
本ファイルは実装予定です。
次回のアップデートで実装を行う予定です。
アップデートに関する情報は
https://github.com/darui3018823/thisisbot/releases
の2.4.0に関するバージョンをご確認ください。

en:
This file is planned to be implemented.
It is scheduled to be implemented in the next update.
For information on the update, please check the version for 2.4.0 at
https://github.com/darui3018823/thisisbot/releases
"""

import os
import json
import discord
from discord.ext import commands
from collections import defaultdict

# ここは仮置き。実装済みなら差し替えてください。
def fetch_and_download_audio(url):
    # 実際にはyoutube_dlやyt_dlpで実装されているはず
    return ("タイトル", 300, "アップローダ", "ファイルパス", "ソースURL")

class MusicCog(commands.Cog):
    DEFAULT_VOLUME = 0.5
    DOWNLOAD_LIST_PATH = "./vc/downloadlist.json"

    def __init__(self, bot):
        self.bot = bot
        self.volume_settings = {}
        self.repeat_song = {}
        self.current_song = {}
        self.song_queues = defaultdict(list)
        self.repeat_settings = defaultdict(bool)

        os.makedirs("./vc", exist_ok=True)
        if not os.path.exists(self.DOWNLOAD_LIST_PATH):
            with open(self.DOWNLOAD_LIST_PATH, "w") as f:
                json.dump([], f)

    @commands.command()
    async def repeat(self, ctx):
        """リピートモードを切り替えます"""
        gid = ctx.guild.id
        self.repeat_settings[gid] = not self.repeat_settings[gid]
        state = "有効" if self.repeat_settings[gid] else "無効"

        if self.repeat_settings[gid]:
            if gid in self.current_song and self.current_song[gid]:
                self.repeat_song[gid] = self.current_song[gid]
                print(f"[DEBUG] リピート曲設定: {self.repeat_song[gid][0]}")
            else:
                await ctx.send(embed=discord.Embed(
                    title="リピートエラー",
                    description="現在再生中の曲が見つかりません。",
                    color=0xff0000
                ))
                return
        else:
            self.repeat_song[gid] = None

        embed = discord.Embed(
            title="リピート設定",
            description=f"一曲リピートを {state} に切り替えました。",
            color=0x00ff00 if self.repeat_settings[gid] else 0xff0000
        )
        await ctx.send(embed=embed)

    @commands.command()
    async def join(self, ctx, url: str):
        if ctx.author.voice is None:
            await ctx.send("ボイスチャンネルに接続してください。")
            return

        try:
            vc = await ctx.author.voice.channel.connect()
        except discord.ClientException:
            vc = ctx.voice_client  # 既に接続されている場合

        song = fetch_and_download_audio(url)
        if song:
            self.song_queues[ctx.guild.id] = []
            await self.play_song(vc, ctx, song)

    @commands.command()
    async def add(self, ctx, url: str):
        if ctx.voice_client is None or not ctx.voice_client.is_connected():
            await ctx.send("ボイスチャンネルに接続していません。最初に `daruks!join` を使用してください。")
            return

        song = fetch_and_download_audio(url)
        if song:
            self.song_queues[ctx.guild.id].append(song)
            title, duration, uploader, _, _ = song
            embed = discord.Embed(title="キューに追加しました", color=0x0000ff)
            embed.add_field(name="曲名", value=title, inline=False)
            embed.add_field(name="動画時間", value=f"{duration // 60}:{duration % 60:02}", inline=True)
            embed.add_field(name="アーティスト", value=uploader, inline=True)
            await ctx.send(embed=embed)

    async def play_song(self, vc, ctx, song):
        title, duration, uploader, filepath, _ = song
        self.current_song[ctx.guild.id] = song
        vc.play(discord.FFmpegPCMAudio(filepath), after=lambda e: self.after_song(ctx))

        embed = discord.Embed(title="再生中 🎶", color=0x00ffff)
        embed.add_field(name="曲名", value=title, inline=False)
        embed.add_field(name="時間", value=f"{duration // 60}:{duration % 60:02}", inline=True)
        embed.add_field(name="アーティスト", value=uploader, inline=True)
        await ctx.send(embed=embed)

    def after_song(self, ctx):
        gid = ctx.guild.id
        vc = ctx.voice_client

        if self.repeat_settings[gid] and self.repeat_song.get(gid):
            song = self.repeat_song[gid]
            coro = self.play_song(vc, ctx, song)
        elif self.song_queues[gid]:
            song = self.song_queues[gid].pop(0)
            coro = self.play_song(vc, ctx, song)
        else:
            coro = vc.disconnect()

        fut = commands.Bot.loop.create_task(coro)
        fut.add_done_callback(lambda f: f.exception())

async def setup(bot):
    await bot.add_cog(MusicCog(bot))
