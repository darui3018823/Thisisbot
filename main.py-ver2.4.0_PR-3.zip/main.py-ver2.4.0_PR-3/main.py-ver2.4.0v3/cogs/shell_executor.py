import os
import logging
import discord
import subprocess
from discord.ext import commands
from datetime import datetime


def setup_single_log_logger(name: str, directory: str):
    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    log_filename = f"{timestamp}.log"
    log_path = os.path.join(directory, log_filename)

    os.makedirs(directory, exist_ok=True)

    logger = logging.getLogger(f"{name}_{timestamp}")
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        handler = logging.FileHandler(log_path, encoding="utf-8")
        formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger, log_path


class ShellExecutor(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.botversion = "Released by This is bot Ver.2.4.0 Pre-Release v3"
        self.daruks = 973782871963762698

    def is_authorized(self, user_id):
        return user_id == self.daruks

    async def _execute_command(self, ctx, command, shell_type, shell_cmd, log_dir, color):
        if not self.is_authorized(ctx.author.id):
            await ctx.send("あなたにはこのコマンドを実行する権限がありません。")
            return

        logger, log_path = setup_single_log_logger(shell_type, log_dir)

        try:
            result = subprocess.run(
                shell_cmd + [command],
                capture_output=True, text=True, shell=True
            )
            output = result.stdout or result.stderr

            logger.info(f"{shell_type.upper()} Command: {command}")
            logger.info("Output:\n" + output)

            embed = discord.Embed(title=shell_type.upper(), color=color)
            embed.add_field(name="Run Command:", value=command, inline=False)
            embed.add_field(name="Log File", value=log_path)
            embed.set_footer(text=f"Bot {self.botversion}")
            await ctx.send(embed=embed)

        except Exception as e:
            logger.error(f"エラー: {str(e)}")
            await ctx.send(f"エラーが発生しました: {str(e)}")

    @commands.command(name="cmd")
    async def cmd_command(self, ctx, *, command: str):
        await self._execute_command(
            ctx, command, shell_type="cmd",
            shell_cmd=["cmd", "/c"], log_dir="./Temp/command/cmd/",
            color=0xffcc00
        )

    @commands.command(name="powershell", aliases=["ps"])
    async def powershell_command(self, ctx, *, command: str):
        await self._execute_command(
            ctx, command, shell_type="powershell",
            shell_cmd=["powershell", "-Command"], log_dir="./Temp/command/powershell/",
            color=0x00afcc
        )

    @commands.command(name="pwsh")
    async def pwsh_command(self, ctx, *, command: str):
        await self._execute_command(
            ctx, command, shell_type="pwsh",
            shell_cmd=["pwsh", "-Command"], log_dir="./Temp/command/pwsh/",
            color=0x537895
        )


async def setup(bot):
    await bot.add_cog(ShellExecutor(bot))
