import logging


# ログの共通設定（1回だけ設定）
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(name)s] [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

#prefix cmd
prefix_ping_logging = logging.getLogger('prefix_ping')

# slash cmd
cmdlist_logging = logging.getLogger('cmdlist')
invite_logging = logging.getLogger('invite')
restart_logging = logging.getLogger('restart')
status_logging = logging.getLogger('pc_status')
userinfo_logging = logging.getLogger('userinfo')
pc_status_logging = logging.getLogger('pc_status')
track_logging = logging.getLogger('track')
site_sc_logging = logging.getLogger('site_sc')
yt_dlp_logging = logging.getLogger('yt-dlp')
random_logging = logging.getLogger('random')
calc_logging = logging.getLogger('calc')
moayai_logging = logging.getLogger('moayai')
rate_logging = logging.getLogger('rate')
contact_logging = logging.getLogger('contact')
re_contact_logging = logging.getLogger('re_contact')

# imports
imports_utility_logging = logging.getLogger('imports_utility')