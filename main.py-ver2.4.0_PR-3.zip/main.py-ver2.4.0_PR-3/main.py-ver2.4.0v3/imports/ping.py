import datetime
import time
from turtle import up
import discord
from discord.ext import commands
from imports.logging import prefix_ping_logging

testing_server_id = 'plz_change_this' # int

async def checking_rtt(ctx, bot):
    prefix_ping_logging.info("Starting checking_rtt.")
    
    cmd_uptime = time.time()
    rtts = []
    latencys = []
    test_channel = bot.get_channel(testing_server_id)
    
    if test_channel is None:
        embed = discord.Embed(
            title="Error",
            description="エラーが発生しました。\n`/contact`を使用して`./ping/_server_id_none`とともに送信してください。",
            color=0xff0000
        )
        prefix_ping_logging.error("test_server_id is None.")
        await ctx.send(embed=embed)
        return
    
    for i in range(5):
        try:
            start_time = time.time()
            msg = await test_channel.send("[RTT] 🏓 計測中...")
            prefix_ping_logging.info(f"[RTT] Message Send to {test_channel.name}")
            endtime = time.time()
            rtt_time = round((endtime - start_time) * 1000)
            prefix_ping_logging.info("[RTT] RTT: %s", rtt_time)
            rtts.append(rtt_time)
        except Exception as e:
            prefix_ping_logging.error("[RTT] Error in checking_rtt: %s", str(e))
            await ctx.send("RTTの計測中にエラーが発生しました。")
            return
    
    avg_rtt = sum(rtts) / len(rtts)
    prefix_ping_logging.info(f"Average RTT: {avg_rtt}ms")
    rtt_list_str = "\n".join([f"計測{i+1}: {rtts[i]}ms" for i in range(len(rtts))])
    
    time.sleep(5)
    
    for _ in range(5):
        try:
            start_time = time.time()
            msg = await test_channel.send("[Latency] 🏓 計測中...")
            prefix_ping_logging.info(f"[Latency] Message Send to {test_channel.name}")
            endtime = time.time()
            latency_time = round((endtime - start_time) * 1000)
            prefix_ping_logging.info("[Latency] WebSocket Latency: %s", latency_time)
            latencys.append(latency_time)
        except Exception as e:
            prefix_ping_logging.error("[Latency] Error in checking_rtt: %s", str(e))
            await ctx.send("WebSocketのLatencyの計測中にエラーが発生しました。")
            return
        
    avg_websocket = sum(latencys) / len(latencys)
    prefix_ping_logging.info(f"Average WebSocket Latency: {avg_websocket}ms")
    latency_list_str = "\n".join([f"計測{i+1}: {latencys[i]}ms" for i in range(len(latencys))])
    
    uptime_sec = time.time() - cmd_uptime - 5
    prefix_ping_logging.info(f"Total Uptime: {uptime_sec + 5}")
    minutes = int(uptime_sec // 60)  # min
    seconds = int(uptime_sec % 60)  # sec
    milliseconds = int((uptime_sec - int(uptime_sec)) * 1000) #ms
    uptime_str = f"{minutes:02}:{seconds:02}.{milliseconds:05}"
    prefix_ping_logging.info(f"Uptime: {uptime_str}")
    
    embed = discord.Embed(
        title="🏓 RTT 測定結果",
        color=0x00ff00
    )
    embed.add_field(name="測定回数", value="計10回", inline=True)
    embed.add_field(name="合計時間", value=uptime_str, inline=True)
    embed.add_field(name="", value="", inline=False)
    embed.add_field(name="Avg. RTT", value=f"{round(avg_rtt)} ms", inline=True)
    embed.add_field(name="Max. RTT", value=f"{max(rtts)} ms", inline=True)
    embed.add_field(name="Min. RTT", value=f"{min(rtts)} ms", inline=True)
    embed.add_field(name="RTT List", value=rtt_list_str, inline=False)
    embed.add_field(name="", value="", inline=False)
    embed.add_field(name="Avg. Latency", value=f"{round(avg_websocket)} ms", inline=True)
    embed.add_field(name="Max. Latency", value=f"{max(latencys)} ms", inline=True)
    embed.add_field(name="Min. Latency", value=f"{min(latencys)} ms", inline=True)
    embed.add_field(name="Latency List", value=latency_list_str, inline=False)
    embed.set_footer(text=f"Request: {ctx.author.display_name} (ID: {ctx.author.id})", icon_url=ctx.author.display_avatar.url)
    
    await ctx.send(embed=embed)
    prefix_ping_logging.info("End checking_rtt.")

async def checking_rtt_tree(interaction, bot):
    prefix_ping_logging.info("Starting checking_rtt.")
    await interaction.response.defer(thinking=True)
    
    cmd_uptime = time.time()
    rtts = []
    latencys = []
    test_channel = bot.get_channel(testing_server_id)
    
    if test_channel is None:
        embed = discord.Embed(
            title="Error",
            description="エラーが発生しました。\n`/contact`を使用して`./ping/_server_id_none`とともに送信してください。",
            color=0xff0000
        )
        prefix_ping_logging.error("test_server_id is None.")
        await interaction.followup.send(embed=embed)
        return
    
    for i in range(5):
        try:
            start_time = time.time()
            msg = await test_channel.send("[RTT] 🏓 計測中...")
            prefix_ping_logging.info(f"[RTT] Message Send to {test_channel.name}")
            endtime = time.time()
            rtt_time = round((endtime - start_time) * 1000)
            prefix_ping_logging.info("[RTT] RTT: %s", rtt_time)
            rtts.append(rtt_time)
        except Exception as e:
            prefix_ping_logging.error("[RTT] Error in checking_rtt: %s", str(e))
            await interaction.followup.send("RTTの計測中にエラーが発生しました。")
            return
    
    avg_rtt = sum(rtts) / len(rtts)
    prefix_ping_logging.info(f"Average RTT: {avg_rtt}ms")
    rtt_list_str = "\n".join([f"計測{i+1}: {rtts[i]}ms" for i in range(len(rtts))])
    
    time.sleep(5)
    
    for _ in range(5):
        try:
            start_time = time.time()
            msg = await test_channel.send("[Latency] 🏓 計測中...")
            prefix_ping_logging.info(f"[Latency] Message Send to {test_channel.name}")
            endtime = time.time()
            latency_time = round((endtime - start_time) * 1000)
            prefix_ping_logging.info("[Latency] WebSocket Latency: %s", latency_time)
            latencys.append(latency_time)
        except Exception as e:
            prefix_ping_logging.error("[Latency] Error in checking_rtt: %s", str(e))
            await interaction.followup.send("WebSocketのLatencyの計測中にエラーが発生しました。")
            return
        
    avg_websocket = sum(latencys) / len(latencys)
    prefix_ping_logging.info(f"Average WebSocket Latency: {avg_websocket}ms")
    latency_list_str = "\n".join([f"計測{i+1}: {latencys[i]}ms" for i in range(len(latencys))])
    
    uptime_sec = time.time() - cmd_uptime - 5
    prefix_ping_logging.info(f"Total Uptime: {uptime_sec + 5}")
    minutes = int(uptime_sec // 60)  # min
    seconds = int(uptime_sec % 60)  # sec
    milliseconds = int((uptime_sec - int(uptime_sec)) * 1000) #ms
    uptime_str = f"{minutes:02}:{seconds:02}.{milliseconds:05}"
    prefix_ping_logging.info(f"Uptime: {uptime_str}")
    
    embed = discord.Embed(
        title="🏓 RTT 測定結果",
        color=0x00ff00
    )
    embed.add_field(name="測定回数", value="計10回", inline=True)
    embed.add_field(name="合計時間", value=uptime_str, inline=True)
    embed.add_field(name="", value="", inline=False)
    embed.add_field(name="Avg. RTT", value=f"{round(avg_rtt)} ms", inline=True)
    embed.add_field(name="Max. RTT", value=f"{max(rtts)} ms", inline=True)
    embed.add_field(name="Min. RTT", value=f"{min(rtts)} ms", inline=True)
    embed.add_field(name="RTT List", value=rtt_list_str, inline=False)
    embed.add_field(name="", value="", inline=False)
    embed.add_field(name="Avg. Latency", value=f"{round(avg_websocket)} ms", inline=True)
    embed.add_field(name="Max. Latency", value=f"{max(latencys)} ms", inline=True)
    embed.add_field(name="Min. Latency", value=f"{min(latencys)} ms", inline=True)
    embed.add_field(name="Latency List", value=latency_list_str, inline=False)
    embed.set_footer(text=f"Request: {interaction.user.display_name} (ID: {interaction.user.id})", icon_url=interaction.user.display_avatar.url)
    
    await interaction.followup.send(embed=embed)
    prefix_ping_logging.info("End checking_rtt.")
