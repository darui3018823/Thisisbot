from datetime import datetime
import os
from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from imports.logging import track_logging

track_savedir = "./Temp/track/"

# Track cmd
async def take_screenshot(url, tracking_id, interaction):
    track_logging.info(f"Starting screenshot capture for Tracking ID: {tracking_id}")
    
    firefox_options = FirefoxOptions()
    firefox_options.add_argument('--headless')  # ヘッドレスモードで起動
    firefox_options.add_argument('--window-size=1920x1080')  # ウィンドウサイズの指定
    
    service = FirefoxService(executable_path='C:/geckodriver/geckodriver.exe')  # geckodriver のパスを設定
    driver = webdriver.Firefox(service=service, options=firefox_options)
    track_logging.info("Firefox WebDriver initialized successfully.")

    try:
        track_logging.info(f"Navigating to URL: {url}")
        driver.get(url)
        
        # ページのサイズを取得
        body = driver.find_element(By.TAG_NAME, 'body')
        body_width = body.size['width']
        body_height = body.size['height']
        
        track_logging.debug(f"Page dimensions - Width: {body_width}, Height: {body_height}")

        # ウィンドウサイズを設定
        driver.set_window_size(body_width, body_height)
        
        temp_screenshot_path = f"screenshot_{tracking_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        driver.save_screenshot(temp_screenshot_path)
        track_logging.info(f"Temporary screenshot saved at: {temp_screenshot_path}")
        
        if not os.path.exists(track_savedir):
            os.makedirs(track_savedir)
            track_logging.info(f"Created directory: {track_savedir}")
        
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        screenshot_path = os.path.join(track_savedir, f"{interaction.user.id}_{tracking_id}_{timestamp}_temp.png")
        
        driver.save_screenshot(screenshot_path)
        track_logging.info(f"Final screenshot saved at: {screenshot_path}")
        
        return screenshot_path
    except Exception as e:
        track_logging.error(f"Error occurred while capturing screenshot: {e}")
        return None
    finally:
        driver.quit()
        track_logging.info("WebDriver session closed.")
