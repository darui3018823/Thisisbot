import re
import string
import random
import discord
from imports.logging import contact_logging, re_contact_logging

daruksid = 973782871963762698
botversion = 'Ver.2.4.0 Pre-Release v3'

class ReplyMethodSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Discord", description="DiscordのDMで返信を希望"),
            discord.SelectOption(label="メール", description="メールで返信を希望"),
            discord.SelectOption(label="その他", description="その他の方法で返信を希望"),
            discord.SelectOption(label="返信を希望しない", description="返信は不要です"),
        ]
        super().__init__(placeholder="返信方法を選択してください", options=options)

    async def callback(self, interaction: discord.Interaction):
        # 選択された返信方法を取得
        selected_reply_method = self.values[0]
        await handle_modal(interaction, selected_reply_method)
        contact_logging.debug(f"Reply method selected: {selected_reply_method}")
        


class ReplyMethodView(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.add_item(ReplyMethodSelect())
        
# チケット番号を生成する関数
def generate_ticket_number():
    return ''.join(random.choices(string.ascii_uppercase + string.ascii_lowercase + string.digits, k=6))


async def handle_modal(interaction: discord.Interaction, reply_method: str):
    modal = discord.ui.Modal(title="お問い合わせフォーム")
    contact_logging.debug("Creates a modal.")

    # 共通項目を追加
    common_inputs = [
        discord.ui.TextInput(
            label="お問い合わせの概要 (簡潔に)",
            style=discord.TextStyle.short,
            required=True,
            placeholder="例: daruks!pingが反応しない",
        ),
        discord.ui.TextInput(
            label="お問い合わせの本文",
            style=discord.TextStyle.long,
            required=True,
            placeholder="例: ここのこれが動かなくて...",
        ),
        discord.ui.TextInput(
            label="使用端末",
            style=discord.TextStyle.short,
            required=True,
            placeholder="例: iPhone 14 Pro, Google Pixel 6a",
        ),
        discord.ui.TextInput(
            label="端末のOS",
            style=discord.TextStyle.short,
            required=True,
            placeholder="例: iOS 17.7(21H16), Android 12.1.0_r8, Windows 11 (23H2)"
        ),
    ]

    for input_field in common_inputs:
        modal.add_item(input_field)

    # 返信方法に応じた追加項目
    if reply_method == "Discord":
        reply_input = discord.ui.TextInput(
            label="Discordユーザーネーム",
            style=discord.TextStyle.short,
            required=True,
            placeholder="例: username",
        )
        modal.add_item(reply_input)
    elif reply_method == "メール":
        reply_input = discord.ui.TextInput(
            label="返信をご希望のメールアドレス",
            style=discord.TextStyle.short,
            required=True,
            placeholder="例: example@domain.com",
        )
        modal.add_item(reply_input)
    elif reply_method == "その他":
        reply_platform = discord.ui.TextInput(
            label="返信をご希望のプラットフォーム",
            style=discord.TextStyle.short,
            required=True,
            placeholder="例: Twitter, Instagram",
        )
        reply_input = discord.ui.TextInput(
            label="プラットフォームのユーザー名等",
            style=discord.TextStyle.long,
            required=True,
            placeholder="例: @example",
        )
        modal.add_item(reply_platform)
        modal.add_item(reply_input)

    async def modal_callback(modal_interaction: discord.Interaction):
        # チケット番号を生成
        ticket_number = generate_ticket_number()

        # Embedを作成
        embed = discord.Embed(
            title="新しいお問い合わせ",
            description="ユーザーから新しいお問い合わせがありました。",
            color=0x00ff00,
        )
        # 共通項目をEmbedに追加
        embed.add_field(name="お問い合わせの概要", value=common_inputs[0].value, inline=False)
        embed.add_field(name="お問い合わせの本文", value=common_inputs[1].value, inline=False)
        embed.add_field(name="使用端末", value=common_inputs[2].value, inline=True)
        embed.add_field(name="端末のOS", value=common_inputs[3].value, inline=True)
        embed.add_field(name="チケット番号", value=ticket_number, inline=False)

        # 返信方法に応じた項目をEmbedに追加
        if reply_method == "Discord":
            embed.add_field(name="Discordユーザーネーム", value=reply_input.value, inline=False)
        elif reply_method == "メール":
            embed.add_field(name="メールアドレス", value=reply_input.value, inline=False)
        elif reply_method == "その他":
            embed.add_field(name="プラットフォーム", value=reply_platform.value, inline=True)
            embed.add_field(name="ユーザー名等", value=reply_input.value, inline=True)

        embed.set_footer(
            text=f"送信者: {modal_interaction.user} (ID: {modal_interaction.user.id})\n"
                 f"送信日時: {modal_interaction.created_at}"
        )

        # 管理者に送信
        owner = await modal_interaction.client.fetch_user(daruksid)
        await owner.send(embed=embed)

        send_complete_embed = discord.Embed(
            title="お問い合わせの受付完了",
            description=f"お問い合わせありがとうございます。\n"
                        f"チケット番号は `{ticket_number}` です。\n"
                        "このチケット番号は再発行不可ですので、紛失しないよう十分お気を付けください。\n"
                        "通常1~3日以内に返信いたします。\n"
                        "一週間以上返信がない場合は、`/re_contact`より再度お問い合わせをしてください。",
            color=0x00ff00,
        )
        send_complete_embed.set_footer(text=f"Bot {botversion}")
        await modal_interaction.response.send_message(embed=send_complete_embed, ephemeral=True)

    modal.on_submit = modal_callback
    contact_logging.debug("The contact has been sent to the administrator and a reply has been sent to the person who contacted us.")
    await interaction.response.send_modal(modal)


# re_contactの処理
async def handle_resend_modal(interaction):
    modal = discord.ui.Modal(title="再度お問い合わせ")

    ticket_input = discord.ui.TextInput(
        label="対象のチケット番号",
        style=discord.TextStyle.short,
        required=True,
        placeholder="例: ABC123",
    )
    modal.add_item(ticket_input)

    async def modal_callback(modal_interaction: discord.Interaction):
        resend_contact = discord.Embed(
            title="ユーザーからの再度お問い合わせ",
            description=f"ユーザーから再度お問い合わせがありました。\n"
                        f"対象のチケット番号: `{ticket_input.value}`",
            color=0x00ff00,
        )
        resend_contact.set_footer(
            text=f"送信者: {modal_interaction.user} (ID: {modal_interaction.user.id})\n"
                 f"送信日時: {modal_interaction.created_at}"
        )

        owner = await modal_interaction.client.fetch_user(daruksid)
        await owner.send(embed=resend_contact)

        resend_reply = discord.Embed(
            title="お問い合わせの受付完了",
            description=f"再度のお問い合わせありがとうございます。\n"
                        f"チケット番号 `{ticket_input.value}` のお問い合わせを受け付けました。\n"
                        "この度はお手数をおかけいたしまして申し訳ございません。\n"
                        "通常1~3日以内に返信いたします。\n"
                        "このメッセージ後さらに1週間以上返信がない場合は、チケット番号をお確かめの上、再度お問い合わせをお願いいたします。",
            color=0x00ff00,
        )
        resend_reply.set_footer(text=f"Bot {botversion}")
        await modal_interaction.response.send_message(
            embed=resend_reply,
            ephemeral=True,
        )

    modal.on_submit = modal_callback
    re_contact_logging.debug("All reminders have been sent to the Re_Contact administrator and replies have been sent to the person who made the inquiry.")
    await interaction.response.send_modal(modal)

# daruks!contactの処理
async def prefix_contactcmd(botversion):
    embed = discord.Embed(
        title="❗ コマンド変更のお知らせ",
        description=(
            "このコマンドは `/contact` に変更されました。\n"
            "環境等の問題によりスラッシュコマンドをご利用いただけない場合は以下の方法をご利用ください。"
        ),
        color=0xff0000
    )
    embed.add_field(name="お問い合わせ先", value=(
        "- **Mail**: `contact@daruks.com`\n"
        "- **Form**: [お問い合わせフォーム](https://daruks.com/Contact/)"
    ), inline=False)
    embed.set_footer(text=f"ご不便をおかけしますが、ご理解のほどよろしくお願いいたします。\nBot {botversion}")
    return embed
