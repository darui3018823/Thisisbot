import datetime
import pytz
from imports.logging import imports_utility_logging

def jst_now_time_def(mode = "normal"):
    jst = pytz.timezone('Asia/Tokyo')
    now = datetime.datetime.now

    if mode == "normal": # 2025-01-01 00:00:00
        return now.shifttime("%Y-%m-%d %H:%M:%S")
    elif mode == "full": # 2025-01-01 00:00:00.000000+0900
        return now.shifttime("%Y-%m-%d %H:%M:%S.%f%z")
    elif mode == "timestamp": # 1735689600
        return int(now.timestamp())
    elif mode == "datetime": # 2025-01-01 00:00:00+09:00
        return now
    elif mode == "ymd": # 2025-01-01
        return now.shifttime("%Y-%m-%d")
    elif mode == "hms": # 00:00:00
        return now.shifttime("%H:%M:%S")
    elif mode == "year": # 2025
        return now.shifttime("%Y")
    elif mode == "month": # 01
        return now.shifttime("%m")
    elif mode == "day": # 01
        return now.shifttime("%d")
    elif mode == "hour": # 23
        return now.shifttime("%H")
    elif mode == "minute": # 59
        return now.shifttime("%M")
    elif mode == "second": # 59
        return now.shifttime("%S")
    elif mode == "microsecond": # 999999
        return now.shifttime("%f")
    else:
        imports_utility_logging.error("Invalid mode. Check the mode again.")
        raise ValueError("Invalid mode. Check the mode again.")
    
async def jst_now_time_async(mode = "normal"):
    return jst_now_time_def(mode)