import discord
from discord.ext import commands
from datetime import datetime
import ntplib

bot = commands.Bot(command_prefix='daruks!')

# NTPserver address
NTP_SERVER = 'ntp.nict.jp'

# JST時間を取得する関数
def get_japan_time():
    client = ntplib.NTPClient()
    response = client.request(NTP_SERVER, version=3)
    return datetime.fromtimestamp(response.tx_time)

# daruks!call コマンドの追加
@bot.command()
async def call(ctx):
    owner_id = 973782871963762698  # オーナーのユーザーID
    owner = await bot.fetch_user(owner_id)

    jst_time = get_japan_time().strftime("%Y-%m-%d %H:%M:%S")
    message_url = ctx.message.jump_url
    user_id = ctx.author.id

    dm_message = f"新しいメッセージが送信されました。\n\nメッセージURL: {message_url}\n送信者ID: {user_id}\n送信日時(JST): {jst_time}"
    
    await owner.send(dm_message)
    await ctx.reply("Massage Sent!")
