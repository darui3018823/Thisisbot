import discord
from discord.ext import commands
from datetime import datetime, timedelta
import os

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='daruks!', intents=intents)

# ヘルプコマンド
@bot.command(name='daruks_help')
async def help_command(ctx):
    await ctx.reply("How to Commands\nヘルプを表示したいdaruks!コマンドを\n`daruksh `のように入力してください。")

# コマンドのヘルプメッセージ
@bot.event
async def on_message(message):
    if message.content.startswith('daruksh!'):
        cmd = message.content.split('!')[1]
        help_msgs = {
            'delete': 'bot massage delete\n`daruks!delete `\n※Please send it by reply',
            'myid': 'Display your user ID\n`daruks!myid `',
            'help': 'This command\n`daruks!help `',
            'ping': 'Measure the bot’s latency\n`daruks!ping `',
            'jst': 'display JST time\n`daruks!jst `',
            'whois': 'Search for the whois information of the received IP address.\n`daruks!whois (v4 or v6 address)`',
            'utc': 'display utc time\n`daruks!utc `',
            'cmdlist': 'display command list\n`daruks!cmdlist `',
            'contact': 'This command is only available for this bot\'s dm.\n`daruks!contact `',
            'update': 'You can see the\nupdate history and schedule of this bot.\n `daruks!update `'
        }
        if cmd in help_msgs:
            await message.reply(help_msgs[cmd])
        else:
            await message.reply("Unknown command.")
    await bot.process_commands(message)

# contact
@bot.event
async def on_message(message):
    if isinstance(message.channel, discord.DMChannel):
        if message.content == "daruks!contact":
            await message.author.send(
                "ご連絡ありがとうございます。\nリプライをせずにこのメッセージのあとに、main!を付けて送信くださいませ。\n以下にテンプレートを掲載します。ご利用ください。\nキャンセルする際はcancel!とご入力ください。\nメールでのご連絡をご希望の場合はmail!とご入力ください。\n※お問い合わせ内容は1,2行で簡潔にご記入ください\n※ユーザー名は返信を希望される場合は記入ください。\n\nmain!\nお問い合わせ内容:\nユーザー名:\n利用端末:\n本文:"
            )
        elif message.content == "cancel!":
            await message.author.send("チケットを終了しました。\n再度ご利用になる場合は`daruks!contact`とご入力ください。")
        elif message.content == "mail!":
            await message.author.send(
                "メールでのご連絡を承ります。\n以下の情報を送信ください。\n\nメールアドレス:\nご連絡を希望のメールアドレス:\nお問い合わせ内容:"
            )
        elif message.content.startswith("main!"):
            owner = await bot.fetch_user(973782871963762698)
            await owner.send(
                f"{message.content}\n\n送信者詳細\nユーザー名: {message.author.name}\nユーザーID: {message.author.id}\n送信日時: {message.created_at}"
            )
        elif message.content.startswith("sent!"):
            owner = await bot.fetch_user(973782871963762698)
            await owner.send(
                f"{message.content}\n\n送信者詳細\nユーザー名: {message.author.name}\nユーザーID: {message.author.id}\n送信日時: {message.created_at}"
            )
            await message.author.send(
                "ありがとうございます。\n確認次第、お問い合わせ内容の再確認メールをこちらから送信いたします。\n@icloud.comからのメールがブロックされている場合はメールが届かない可能性があります。"
            )
    else:
        if message.content == "daruks!contact":
            await message.channel.send("このコマンドはDMでのみ使用できます。")


    # Handle the daruks!update command
    if message.content == "daruks!update":
        update_history = """Update History
Ver1.0
Initial release

Ver.1.1(now)
Stable Version
-Minor bug fixes
-add new daruks! commands

Ver1.2
Pending Version
-Minor bug fixes
-Add whois command
-Add Auto reply
-Add contact command

Ver1.7
Beta Version
-Add Admin perm add command
-Add Calculus Command
-Add !cmdlist

Ver2.0
Under development
-Fixed a serious bug
-Add help command
-Enhanced contact command
Functions will be added in the future!"""
        await message.reply(update_history)
        return

    await bot.process_commands(message)

# Auto reply
@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    bad_words = ["死ね", "しね", "シネ", "カス", "かす"]
    for word in bad_words:
        if word in message.content:
            await message.reply("そんなこと言うのは良くないよお前が死ね")
            return

    kazume_words = ["かずめ", "kazume", "ぴぃまん", "ぴいまん"]
    for word in kazume_words:
        if word in message.content:
            await message.reply("捕まろうよ〜🥰")
            return

    osu_words = ["osu!", "osu", "kasu!", "gomi!", "otu!"]
    for word in osu_words:
        if word in message.content:
            await message.reply("お前もwelcome to osu!")
            return

    paypal_words = ["ぺいぱる", "ペイパル", "PayPal"]
    for word in paypal_words:
        if word in message.content:
            await message.reply("割ってなんぼやで😎")
            return

    if "えっち" in message.content:
        await message.reply("えっちなのはダメ!死刑!!")
        return

    await bot.process_commands(message)
