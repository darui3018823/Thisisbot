this is bot ver1.7

import discord
from discord.ext import commands
from discord import app_commands
import whois
import ntplib
from datetime import datetime, timedelta
import re

# ボットのインテントを設定
intents = discord.Intents.default()
intents.message_content = True
intents.dm_messages = True

# ボットのプレフィックスを設定
bot = commands.Bot(command_prefix='daruks!', intents=intents)

# 管理者ユーザーIDを設定
ADMIN_USER_ID = 973782871963762698

# NTPserver address
NTP_SERVER = 'ntp.nict.jp'

# Get JST from NTP server
def get_japan_time():
    client = ntplib.NTPClient()
    response = client.request(NTP_SERVER, version=3)
    return datetime.fromtimestamp(response.tx_time)

# WHOIS情報を取得する関数
def get_whois_info(ip_address, ipv6=False):
    try:
        if ipv6 and not re.match(r"([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|2[0-4][0-9]|[0-1][0-9][0-9]|[1-9]?[0-9]))", ip_address):
            return "送信されたアドレスはIPv6のようですがIPv6オプションが選択されていなかったようです。お手数ですが再度お試しください。入力されたv6アドレス: {}".format(ip_address)

        if not ipv6 and not re.match(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", ip_address):
            return "このアドレスはIPアドレスではありません。"

        info = whois.whois(ip_address)
        return str(info)
    except whois.parser.PywhoisError:
        return "検索に失敗しました。再度お試しください。"
    except Exception as e:
        return "不明なエラーが発生しました。再度お試しになるか、プロフィールのリンク先のアドレスよりお問い合わせください。"

# 四則演算を行う関数
def calculate(expression):
    try:
        # 記号の置き換え
        expression = expression.replace('＋', '+').replace('ー', '-').replace('×', '*').replace('÷', '/')
        # 計算
        result = eval(expression)
        return result
    except Exception as e:
        return f"エラーが発生しました: {str(e)}"

# ボットの準備完了イベント
@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')
    # bot status
    activity = discord.Game(name="平和にいこうよ〜🥰")
    await bot.change_presence(status=discord.Status.online, activity=activity)

# daruks!calculus コマンド
@bot.command()
async def calculus(ctx, *, expression: str):
    result = calculate(expression)
    await ctx.reply(f'計算結果: {result}')

# スラッシュコマンド /calculus
class CalculusCommand(app_commands.Group):
    @app_commands.command(name="calculate", description="計算を行います")
    async def calculate(self, interaction: discord.Interaction, expression: str, percentage: bool = False):
        result = calculate(expression)
        if percentage:
            result = result * 100
            await interaction.response.send_message(f'計算結果: {result}%')
        else:
            await interaction.response.send_message(f'計算結果: {result}')

bot.tree.add_command(CalculusCommand(name="calculus"))

# その他の既存のコマンド
@bot.command()
async def delete(ctx, num: int):
    if ctx.message.reference:
        referenced_message = await ctx.channel.fetch_message(ctx.message.reference.message_id)
        await referenced_message.delete()
        await ctx.reply(f'{num} 件のメッセージを削除しました')
    else:
        await ctx.reply("削除するメッセージを返信してください")

@bot.command()
async def myid(ctx):
    await ctx.reply(f'あなたのユーザーIDは {ctx.author.id} です')

@bot.command()
async def help(ctx):
    await ctx.reply("やあ、ブロ。これはdaruksのbotやで\n単語に返信するだけやで、ほな。")

@bot.command()
async def ping(ctx):
    latency = round(bot.latency * 1000)
    await ctx.reply(f'Pong! {latency}ms')

@bot.command()
async def jptime(ctx):
    japan_time = get_japan_time()
    await ctx.reply(f'日本標準時: {japan_time.strftime("%Y-%m-%d %H:%M:%S")}')

@bot.command()
async def utc(ctx):
    japan_time = get_japan_time()
    utc_minus_9 = japan_time - timedelta(hours=9)
    await ctx.reply(f'UTC-9:00の時刻: {utc_minus_9.strftime("%Y-%m-%d %H:%M:%S")}')

@bot.command()
async def whois(ctx, ip_address: str):
    result = get_whois_info(ip_address)
    await ctx.reply(result)

@bot.command()
async def cmdlist(ctx):
    cmdlist_message = (
        "This is bot command list\n\n"
        "daruks! commands\n"
        " delete, myid, help\n"
        " cmdlist, jptime, utc\n"
        " whois, calculus\n\n"
        "Auto reply\n"
        "osu!, paypal, kazume etc…"
    )
    await ctx.reply(cmdlist_message)

@bot.command()
async def shutdown(ctx):
    if ctx.author.id == ADMIN_USER_ID:
        await ctx.reply("シャットダウンします...")
        await bot.close()
    else:
        await ctx.reply("このコマンドは管理者のみ実行できます。")

@bot.command()
async def start(ctx):
    if ctx.author.id == ADMIN_USER_ID:
        await ctx.reply("ボットがオンラインになりました！")
        # You cannot programmatically start the bot again once it has been shut down via a command like this.
        # You need to restart the bot's process externally.
    else:
        await ctx.reply("このコマンドは管理者のみ実行できます。")

